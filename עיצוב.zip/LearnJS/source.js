       
document.write("gg");
 